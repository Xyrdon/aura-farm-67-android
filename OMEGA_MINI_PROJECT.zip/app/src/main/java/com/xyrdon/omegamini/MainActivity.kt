package com.xyrdon.omegamini

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

private val Bg = Color(0xFF070A12)
private val Surface = Color(0xFF111927)
private val SurfaceLight = Color(0xFF172232)
private val Cyan = Color(0xFF76F2FF)
private val Violet = Color(0xFFB19CFF)
private val Muted = Color(0xFF94A4B7)
private val White = Color(0xFFF1F6FF)

private data class BatterySnapshot(
    val level: Int,
    val charging: Boolean,
    val temperature: Float?
)

private data class MemorySnapshot(val total: Long, val available: Long)
private data class SensorVector(val x: Float, val y: Float, val z: Float)

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var sample by mutableStateOf<SensorVector?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 10, 18)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        setContent {
            MaterialTheme {
                OmegaMiniApp(
                    sampleProvider = { sample },
                    sensorAvailable = accelerometer != null
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            sample = SensorVector(event.values[0], event.values[1], event.values[2])
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

private fun readBattery(context: Context): BatterySnapshot {
    val intent: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val pct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val rawTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
    return BatterySnapshot(pct, charging, rawTemp.takeIf { it >= 0 }?.div(10f))
}

private fun readMemory(context: Context): MemorySnapshot {
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(info)
    return MemorySnapshot(info.totalMem, info.availMem)
}

private fun gigabytes(bytes: Long): String = String.format(Locale.US, "%.1f ГБ", bytes / 1073741824.0)
private fun decimal(value: Float): String = String.format(Locale.US, "%+.2f", value)

@Composable
private fun OmegaMiniApp(sampleProvider: () -> SensorVector?, sensorAvailable: Boolean) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var page by rememberSaveable { mutableIntStateOf(0) }
    var battery by remember { mutableStateOf(readBattery(context)) }
    var memory by remember { mutableStateOf(readMemory(context)) }
    var responseCount by rememberSaveable { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            battery = readBattery(context)
            memory = readMemory(context)
            delay(2500)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Bg, Color(0xFF0B1121), Bg)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(22.dp))
            Header()
            Spacer(Modifier.height(18.dp))

            Crossfade(
                targetState = page,
                animationSpec = tween(durationMillis = 180),
                label = "native-tab-transition",
                modifier = Modifier.weight(1f)
            ) { tab ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (tab == 0) {
                        Dashboard(
                            battery = battery,
                            memory = memory,
                            responseCount = responseCount,
                            onTest = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                responseCount += 1
                            }
                        )
                    } else {
                        Sensors(sampleProvider(), sensorAvailable)
                    }
                }
            }
            Navigation(page = page, onSelect = {
                page = it
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            })
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("OMEGA  /  MINI", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text("NATIVE DEVICE TERMINAL  ·  0.1", color = Muted, fontSize = 10.sp, letterSpacing = 1.1.sp)
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(100.dp))
                .background(Color(0xFF16332F))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Box(Modifier.size(6.dp).background(Color(0xFF79F3C8), CircleShape))
            Spacer(Modifier.size(6.dp))
            Text("ONLINE", color = Color(0xFF79F3C8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Dashboard(
    battery: BatterySnapshot,
    memory: MemorySnapshot,
    responseCount: Int,
    onTest: () -> Unit
) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            ReactorOrbit()
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                SectionLabel("СИСТЕМА АКТИВНА")
                Spacer(Modifier.height(10.dp))
                Text("ANDROID", fontSize = 22.sp, color = White, fontWeight = FontWeight.ExtraBold)
                Text("Нативный интерфейс", fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(14.dp))
                Text("Без HTML и WebView", fontSize = 11.sp, color = Cyan)
            }
        }
    }

    Panel {
        SectionLabel("01 / ЭНЕРГОСИСТЕМА")
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(if (battery.level >= 0) "${battery.level}%" else "—", color = White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(if (battery.charging) "ЗАРЯЖАЕТСЯ" else "ОТ БАТАРЕИ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        ProgressTrack(if (battery.level >= 0) battery.level / 100f else 0f, Cyan)
        Spacer(Modifier.height(11.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Заряд аккумулятора", color = Muted, fontSize = 12.sp)
            Text(battery.temperature?.let { String.format(Locale.US, "%.1f °C", it) } ?: "Темп. недоступна", color = White, fontSize = 12.sp)
        }
    }

    Panel {
        SectionLabel("02 / ПАМЯТЬ И УСТРОЙСТВО")
        Spacer(Modifier.height(14.dp))
        MetricRow("Модель", Build.MODEL.ifBlank { "Не определена" })
        Spacer(Modifier.height(10.dp))
        MetricRow("Android", Build.VERSION.RELEASE)
        Spacer(Modifier.height(10.dp))
        MetricRow("Оперативная память", gigabytes(memory.total))
        Spacer(Modifier.height(10.dp))
        MetricRow("Свободно ОЗУ", gigabytes(memory.available))
        Spacer(Modifier.height(12.dp))
        val free = if (memory.total > 0L) memory.available.toFloat() / memory.total else 0f
        ProgressTrack(free, Violet)
    }

    Panel {
        SectionLabel("03 / ТЕСТ УПРАВЛЕНИЯ")
        Spacer(Modifier.height(10.dp))
        Text("Проверь нажатие и тактильный отклик Android.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF146C83), Color(0xFF3B428E))))
                .clickable(onClick = onTest)
                .padding(vertical = 15.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("ИСПЫТАТЬ ОТКЛИК · $responseCount", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ReactorOrbit() {
    val transition = rememberInfiniteTransition(label = "reactor-pulse")
    val pulse by transition.animateFloat(
        initialValue = .84f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), repeatMode = RepeatMode.Reverse),
        label = "glow"
    )
    Canvas(Modifier.size(148.dp)) {
        val cx = size.width / 2
        val cy = size.height / 2
        val radius = size.minDimension * .39f
        drawCircle(Cyan.copy(alpha = .08f), radius * pulse, center = Offset(cx, cy))
        drawCircle(Cyan.copy(alpha = .34f), radius, center = Offset(cx, cy), style = Stroke(1.5.dp.toPx()))
        drawCircle(Violet.copy(alpha = .7f), radius * .71f, center = Offset(cx, cy), style = Stroke(2.dp.toPx()))
        drawArc(
            color = Cyan, startAngle = -35f, sweepAngle = 118f, useCenter = false,
            topLeft = Offset(cx - radius, cy - radius), size = Size(radius * 2, radius * 2),
            style = Stroke(3.dp.toPx())
        )
        drawArc(
            color = Violet, startAngle = 155f, sweepAngle = 75f, useCenter = false,
            topLeft = Offset(cx - radius, cy - radius), size = Size(radius * 2, radius * 2),
            style = Stroke(3.dp.toPx())
        )
        drawCircle(Cyan.copy(alpha = .22f), radius * .44f * pulse, center = Offset(cx, cy))
        drawCircle(Cyan, radius = 8.dp.toPx(), center = Offset(cx, cy))
        drawCircle(White, radius = 3.dp.toPx(), center = Offset(cx, cy))
    }
}

@Composable
private fun Sensors(sample: SensorVector?, available: Boolean) {
    Panel {
        SectionLabel("01 / АКСЕЛЕРОМЕТР")
        Spacer(Modifier.height(10.dp))
        Text("Двигай и поворачивай телефон. Значения должны изменяться в реальном времени.", fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(20.dp))
        if (!available) {
            Text("Акселерометр недоступен на этом устройстве", color = Violet, fontSize = 14.sp)
        } else if (sample == null) {
            Text("ОЖИДАНИЕ ДАННЫХ ДАТЧИКА...", color = Cyan, fontSize = 13.sp)
        } else {
            Axis("X", sample.x, Cyan)
            Spacer(Modifier.height(18.dp))
            Axis("Y", sample.y, Violet)
            Spacer(Modifier.height(18.dp))
            Axis("Z", sample.z, Color(0xFF7BF1C4))
        }
    }

    Panel {
        SectionLabel("02 / ВЕКТОР УСКОРЕНИЯ")
        Spacer(Modifier.height(16.dp))
        val magnitude = if (sample == null) null else sqrt(sample.x * sample.x + sample.y * sample.y + sample.z * sample.z)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(magnitude?.let { String.format(Locale.US, "%.2f", it) } ?: "—", color = White, fontSize = 43.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.size(9.dp))
            Text("м/с²", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("Включает земную гравитацию (~9,81 м/с² в покое).", color = Muted, fontSize = 12.sp)
    }

    Panel {
        SectionLabel("03 / ТЕСТ ПЛАВНОСТИ")
        Spacer(Modifier.height(12.dp))
        Text("Переключай вкладки внизу быстро. Сравни плавность нативного интерфейса с нашей HTML-игрой.", color = White, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Text("Датчик читается локально. Интернет не используется.", color = Cyan, fontSize = 11.sp)
    }
}

@Composable
private fun Axis(label: String, value: Float, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp, modifier = Modifier.size(29.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("ОСЬ $label", fontSize = 10.sp, color = Muted)
                Text("${decimal(value)} м/с²", color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(7.dp))
            ProgressTrack((abs(value) / 15f).coerceIn(0f, 1f), color)
        }
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Surface)
            .border(1.dp, White.copy(alpha = .075f), RoundedCornerShape(22.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun SectionLabel(value: String) {
    Text(value, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = White, fontSize = 12.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
    }
}

@Composable
private fun ProgressTrack(progress: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(10.dp)).background(SurfaceLight)) {
        Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().background(color, RoundedCornerShape(10.dp)))
    }
}

@Composable
private fun Navigation(page: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Surface)
            .border(1.dp, White.copy(alpha = .09f), RoundedCornerShape(20.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        NavButton("ОБЗОР", page == 0, Modifier.weight(1f)) { onSelect(0) }
        NavButton("ДАТЧИКИ", page == 1, Modifier.weight(1f)) { onSelect(1) }
    }
}

@Composable
private fun NavButton(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) Color(0xFF20415A) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Cyan else Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}
